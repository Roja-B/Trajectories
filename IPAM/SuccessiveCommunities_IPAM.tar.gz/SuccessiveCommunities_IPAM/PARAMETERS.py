PATH = "/media/data2/roja/IPAM/SuccessiveCommunities_IPAM"
DataPATH = "/media/data2/roja/IPAM/SuccessiveCommunities_IPAM/myRawData"
START_YEAR = 2000
END_YEAR = 2013
WINDOW = 1 # in years
SLIDE = 1 # in years
MODE = "AGGREGATE"
OmitEmails = {"rcaflisch@ipam.ucla.edu"}
